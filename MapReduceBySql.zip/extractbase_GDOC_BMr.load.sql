/* Load extractbase_GDOC pour 82900 */

--NONTEMPORAL DELETE DMUP10CPMS_SOC_0.extractbase_GDOC
NONTEMPORAL DELETE extractbase_GDOC_BMr
WHERE 
DD_TT < '2017-12-22 00:00:00.000000'
and cd_eds_bnq = 82900
;

--NONTEMPORAL INSERT INTO DMUP10CPMS_SOC_0.extractbase_GDOC
NONTEMPORAL INSERT INTO extractbase_GDOC_BMr
	SELECT
	gdoc.CD_EDS_BNQ
	, gdoc.ID_DOC_UNIQUE as "ID_INDEX_UNIQUE"
	, cast(DATE_DOC as date format 'YYYY-MM-DD') as "DATE_DOC"
	, CD_ETAT
	, gdoc.ID_TEC_DOC
	, ID_TEC_TYPE
	, ID_DOC
	, LIB_DOC
	, ID_ARCHIV
	, cast(to_char(DATE_INTEG, 'YYYYMMDDHH24MISSff3') as char(17)) as "DATE_INTEG"
	, cast(to_char(DATE_MAJ,   'YYYYMMDDHH24MISSff3') as char(17)) as "DATE_MAJ"
	, cast(to_char(DATE_SUP,   'YYYYMMDDHH24MISSff3') as char(17)) as "DATE_SUP"
	, ID_TEC_PLAN
	, LIB_ARBO
	, CLE_INDEX
	, ID_INDEX
	, LIB_INDEX
	, VAL_INDEX
	, CLE_INDEX2
	, ID_INDEX2
	, LIB_INDEX2
	, VAL_INDEX2
	, CLE_INDEX3
	, ID_INDEX3
	, LIB_INDEX3
	, VAL_INDEX3
	, CLE_INDEX4
	, ID_INDEX4
	, LIB_INDEX4
	, VAL_INDEX4
	, CLE_INDEX5
	, ID_INDEX5
	, LIB_INDEX5
	, VAL_INDEX5
	, CLE_INDEX6
	, ID_INDEX6
	, LIB_INDEX6
	, VAL_INDEX6
	, CLE_INDEX7
	, ID_INDEX7
	, LIB_INDEX7
	, VAL_INDEX7
	, CLE_INDEX8
	, ID_INDEX8
	, LIB_INDEX8
	, VAL_INDEX8
	, CLE_INDEX9
	, ID_INDEX9
	, LIB_INDEX9
	, VAL_INDEX9
	, CLE_INDEX10
	, ID_INDEX10
	, LIB_INDEX10
	, VAL_INDEX10
	, Cast(Cast(gdoc.DTSIT as date) || ' 00:00:00.000000' as timestamp(6)) DD_TT
	, Cast('9999-12-31 23:59:59.999999' as timestamp(6)) DF_TT
	--from DMUP10DTWH_BKP_0.GDOC_PI  as "gdoc"
	--left outer join DMUP10DTWH_BKP_0.GIND_PIVOT
	from GDOC_PI_BMr  as "gdoc"
	left outer join GIND_PIVOT_BMr as "GIND_PIVOT"
	on (
	gdoc.CD_EDS_BNQ = GIND_PIVOT.CD_EDS_BNQ
	and gdoc.DTSIT = GIND_PIVOT.DTSIT
	and gdoc.ID_TEC_DOC = GIND_PIVOT.ID_TEC_DOC
	and gdoc.ID_DOC_UNIQUE = GIND_PIVOT.ID_INDEX_UNIQUE
	)
	where gdoc.cd_eds_bnq = 82900
	
	on commit not delete
;
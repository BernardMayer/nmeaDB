"""
Project: digi_gps.py - simple UDP packet forwarder of GPS data for Python-enabled Digi products.

Design:
    The main object is gps_system() (in this file) which opens the GPS data stream and
    obtains complete NMEA sentences.  It also manages the status of MOVING, IDLE or IN_ERROR
    for the system by watching the speed and status fields of the "RMC" sentence.

    gps_system() contains a list of gps_destination() objects (also in this file).
    It submits every NMEA sentence to each gps_destination(), and each
    gps_destination() decides if the sentence is to be forwarded or discarded.

    Today, the gps_destination() are assuemd to be one of two forms:
    1) the destination wants every NMEA sentence forwarded, and this code sends EVERY
       sentence in a distinct UDP packet. No attempt (for now) is made to cache or
       combine groups of sentences into 1 packet.

       This form ASSUMES data costs are free - for example on direct Ethernet.
       
    2) the destination only wants a SINGLE important sentence - such as the RMC sentence which
       gives date/time, location and speed. The design IMPLIES that one could add an arbitrary
       list of desired and undesired sentences, however that won't work today/as-is. This would
       require some form of "cache/combine" to group sentences in 1 UDP packet.

       This form ASSUMES data costs money, and allows the user to configure three different
       rates - for example updates once per minute when MOVING and once per 15 minutes when
       IDLE or no GPS reading is available.  There is no averaging or inteligent handling of
       the sent-vs-discarded lines - literally, the 'next' desired NMEA sentence received after
       the time-period expires is forwarded, and all others have been discarded. 

    TODO:
    1) Confirm robust behavior if GPS is faulty/missing (such as /gps/0 cannot be accssed).
       This is different than no signal - this code handles normal GPS messages saying
       no satellites are fixed.
       
    2) Enable packing multiple NMEA sentences in a single UDP. By itself, this offers a minor
       improvement in the send-all by Ethernet form, but more importantly this would allow the
       system to send (for example) two of five NMEA sentences over cost sensitive networks.
       As-is/today the code CANNOT send only 2 of 5 sentences packeted into 1 UDP packet.
       
    3) AES encryption? If the UDP packets are being sent in the clear over public networks, then
       the customer is sending GPS location in the clear. It would be simple to add a fixed or
       shared key encryption to the UDP payload.
       
    4) Enable a simple UDP query by the central system.  As-is/today, no GPS data means no
       data transmissions to the host.  Does no-news mean network problems or that there
       are GPS problems? This query would allow the host to check on the network is healthy
       
    5) Enable a TCP connection to soliciate a single HTTP page showing last GPS update. Think
       of it as a one-shot web-page.  This would probably include a summary and a short
       snap-shot of the actual NMEA sentence stream for "other" uses.
    
"""

import os
import sys
import traceback
import gc # memory garbage collection

if( sys.platform.startswith('digi')):
    # then we are running on a Digi gateway
    sys.path.append(os.path.join('WEB', 'python', 'python_ext.zip'))
    digiSerial = True

else:
    # else is Windows - pyserial also works under Linux
    digiSerial = False

import socket
import time
import copy

import digi_serial

from digi_nmea import *

showTraceBack = True

from digi_gps_config import *

class gps_system:
    """This class represents one destination for GPS messages
    """

    def __init__( self):
        self.attrib = { GPSDST_NAME:'gps_mommy' }
        self.dest_list = []

    def __getitem__(self, tag):
        return( self.attrib[tag])

    def clear_links( self):
        """Remove any links to other objects - speed up memory garbage collection"""
        return True
    
    def apply_attributes( self, dct):
        """import the attributes for this object; should send in COPY!"""

        # blindly accept these (for now)
        for tag in [GPSDST_PREFER, GPSDST_MOVING,
                    ]:
            if(dct.has_key(tag)):
                self.attrib.update({tag:dct[tag]})
                dct.pop(tag)

        # return any 'bad' values
        return dct    

    # the NAME items
    def get_name( self):
        """Return name for this object as string"""
        return self.attrib.get( GPSDST_NAME, '??')

    def get_is_moving( self):
        """Return if this destination thinks GPS is moving"""
        return self.attrib.get( GPSDST_ISMOVE, False)

    def get_is_error( self):
        """Return if this destination thinks GPS is in error"""
        return self.attrib.get( GPSDST_ISERR, False)

    def get_our_status_string( self):
        """Based on current status, return valid rate rates"""
        if( self.get_is_error() ):
            st = 'GPS is in ERROR !!!!'
        elif( self.get_is_moving() ):
            st = 'GPS says we are moving'
        else: # assume are idle
            st = 'GPS says we are IDLE - not moving'
        return st

    def get_move_tag( self):
        """Return current tag used to detect moving/idle"""
        return self.attrib.get( GPSDST_PREFER, 'RMC')

    def get_move_tolerance( self):
        """Return current knots to define moving, below this is idle"""
        return self.attrib.get( GPSDST_MOVING, 2.5)

    def cache_time_now( self):
        """Store time now - reduce wasted system load"""
        self.now = int(time.time())

    def get_time_now( self):
        """Return seconds since epoch as int"""
        return self.now

    def add_destination( self, cfg):
        """Create a new destination"""
        gps = gps_destination()
        err = gps.apply_attributes( cfg)
        gps.set_parent( self)
        self.dest_list.append( gps)
        return err

    def queue_sentence( self, dct, line=None):
        """Accept a NMEA sentence, consider if to queue, send or disacrd"""

        if not dct.get(NMEA_TALKER, None):
            # then dct is NOT valid - might be garbage or bad CRC
            return False

        try:
            if line:
                # line is assumed full NMEA ready to go
                tag = line[3:6]
            else:
                line = dct[NMEA_RAW]
                tag = dct[NMEA_SENID]
        except:
            print "%s does not like your input" % self.get_name(),
            print line
            return False

        if( tag == self.get_move_tag()):
            # check for errors - are we in error?
            try:
                if( dct[NMEA_STAT] in ['A']):
                    # GPS is Okay, turn error OFF (if on)
                    if(self.get_is_error()):
                        self.attrib.update({GPSDST_ISERR:False})
                else:
                    # GPS is error, turn error ON (if off)
                    if(not self.get_is_error()):
                        self.attrib.update({GPSDST_ISERR:True})
            except:
                if( showTraceBack): traceback.print_exc()

            # check if we are moving
            if( self.get_is_error()):
                # force NOT moving
                if( self.get_is_moving()):
                    self.attrib.update({GPSDST_ISMOVE:False})
            else:
                try:
                    print ">>SPEED: %0.2f Kts - %s" % (dct[NMEA_SPEED], self.get_our_status_string())
                    if( dct[NMEA_SPEED] < self.get_move_tolerance()):
                        # GPS is NOT Moving, turn OFF (if on)
                        if( self.get_is_moving()):
                            self.attrib.update({GPSDST_ISMOVE:False})
                    else:
                        # GPS is Moving, turn ON (if off)
                        if( not self.get_is_moving()):
                            self.attrib.update({GPSDST_ISMOVE:True})
                except:
                    if( showTraceBack): traceback.print_exc()
        
        if( self.dest_list):
            for dest in self.dest_list:
                dest.queue_sentence( dct, line)
                
        return True

class gps_destination:
    """This class represents one destination for GPS messages
    """

    def __init__( self):
        self.attrib = { GPSDST_NAME:'benny' }
        self.clear_links()
        self.sock = None # listen socket; might be socket or other based on ['mode']

    def __getitem__(self, tag):
        return( self.attrib[tag])

    def clear_links( self):
        """Remove any links to other objects - speed up memory garbage collection"""
        self.parent = None
        return True

    def set_parent( self, par):
        self.parent = par
        return

    def apply_attributes( self, dct):
        """import the attributes for this object; should send in COPY!"""

        tag=GPSDST_TYPE
        if(dct.has_key(tag)):
            if( dct[tag] in [None,'udp','UDP']):
                # then is okay
                self.attrib.update({tag:"udp"})
                dct.pop(tag)

        # blindly accept these (for now)
        for tag in [GPSDST_NAME,GPSDST_ADDR,GPSDST_DPORT,GPSDST_SPORT,
                    GPSDST_ONLY, GPSDST_NOSEND,
                    GPSDST_RATEIDLE, GPSDST_RATEMOVE, GPSDST_RATEERR,
                    ]:
            if(dct.has_key(tag)):
                self.attrib.update({tag:dct[tag]})
                dct.pop(tag)

        # return any 'bad' values
        return dct    

    # the NAME items
    def get_name( self):
        """Return name for this object as string"""
        return self.attrib.get( GPSDST_NAME, '??')

    def get_is_moving( self):
        """Return PARENT's opinion if we are moving"""
        return self.parent.get_is_moving()

    def get_is_error( self):
        """Return PARENT's opinion if we are in error"""
        return self.parent.get_is_error()

    def get_time_now( self):
        """Return PARENT's opinion of seconds since epoch as int"""
        return self.parent.get_time_now()

    def get_time_last_send( self):
        """Return seconds since epoch as int"""
        return self.attrib.get( GPSDST_LASTSEND, 0)

    def set_time_last_send( self, now=None):
        """Stores the time we send as int"""
        if not now:
            now = self.get_time_now( )
        self.attrib.update({ GPSDST_LASTSEND:now })
        return now
    
    # the CONFIG items
    def get_address( self):
        """Return current destination address as string"""
        return self.attrib.get( GPSDST_ADDR, '192.168.196.6')

    def get_type( self):
        """Return current destination comm type - 'udp' is only one"""
        return self.attrib.get( GPSDST_TYPE, 'udp')

    def get_dst_port( self):
        """Return current Destination port (default: 2101)"""
        return self.attrib.get( GPSDST_DPORT, GPSDST_DPORT_DEF)

    def get_src_port( self):
        """Return current Source port (default: 0 for random/ephemeral)"""
        return self.attrib.get( GPSDST_SPORT, GPSDST_SPORT_DEF)

    def get_cost_mood( self):
        """Return current cost-awareness level (default: 'cost' = save-money, None = don't care)"""
        return self.attrib.get( GPSDST_MOOD, 'cost')
    
    def get_send_tags( self):
        """Return current list of tags ONLY to send (default: 'RMC', None = send all)"""
        return self.attrib.get( GPSDST_ONLY, ['RMC'])
    
    def get_discard_tags( self):
        """Return current list of tags NOT to send (default: None, ignored if GPSDST_ONLY not None)"""
        return self.attrib.get( GPSDST_NOSEND, None)
    
    def get_rate_moving( self):
        """Return seconds between forwards when moving"""
        return self.attrib.get( GPSDST_RATEIDLE, GPSDST_RATEMOVE_DEF)

    def get_rate_idle( self):
        """Return seconds between forwards when idle"""
        return self.attrib.get( GPSDST_RATEMOVE, GPSDST_RATEIDLE_DEF)

    def get_rate_error( self):
        """Return seconds between forwards when GPS is in error"""
        return self.attrib.get( GPSDST_RATEERR, GPSDST_RATEERR_DEF)

    def get_rate_active( self):
        """Based on current status, return valid rate rates"""
        if( self.get_is_error() ):
            return self.get_rate_error()
        elif( self.get_is_moving() ):
            return self.get_rate_moving()
        else: # assume are idle
            return self.get_rate_idle()
    
    def queue_sentence( self, dct, line):
        """Accept a NMEA sentence, consider if to queue, send or disacrd"""

        try:
            tag = line[3:6]

        except:
            print "%s does not like your input" % self.get_name(),
            print line
            return False

        if self.get_send_tags():
            # then we have at least 1 send-only
            if tag not in self.get_send_tags():
                # then we don't want it
                print "%s does not want <%s> sentences" % (self.get_name(),tag)
                return False

        if self.get_discard_tags():
            # then we have at least 1 do-not-send
            if tag in self.get_discard_tags():
                # then we don't want it
                print "%s discards <%s> sentences" % (self.get_name(),tag)
                return False

        # at this point, we have something might want to move

        rate = self.get_rate_active()
        now = self.get_time_now()
        if( rate == 0):
            # for no rate, always send
            # print 'always send'
            return self.send_sentence( line, now)
            
        else: # we have a rate
            diff = now - self.get_time_last_send()
            if( diff > rate):
                print 'time to send'
                return self.send_sentence( line, now)
            # else: print 'waiting %d seconds more to send' % (rate - diff)

        return False

    def send_sentence( self, line, now=None):
        """Accept a NMEA sentence, consider if to queue, send or disacrd"""

        if( self.sock == None):
            print 'opening the socket'
            self.sock = socket.socket( socket.AF_INET, socket.SOCK_DGRAM)

        self.set_time_last_send( now)

        print '%s sending <%s>' % (self.get_name(), line)

        self.addr = (self.get_address(),self.get_dst_port())
        
        try:
            self.sock.sendto( line, self.addr)
        except:
            if( showTraceBack): traceback.print_exc()
            self.sock = None
            
        return True


def load_gps_system():
    
    gps = gps_system()
    
    # GPS_SYSTEM_CONFIG is in digi_gps_config.py
    cfg = copy.copy( GPS_SYSTEM_CONFIG)
    err = gps.apply_attributes( cfg)
    if err: print 'errors in gps_system_config =', err

    # load the list from digi_gps_config.py
    for dest in GPS_DEST_LIST:
        cfg = copy.copy( dest)
        err = gps.add_destination( cfg)
        if err: print 'errors in dest =', err
        
    return gps

def open_serial_port():
    """Loop and open the port"""
    while True:
        ser = digi_serial.serialPort()
        if( digiSerial):
            # then is USB GPS or other (we don't care)
            ser.attrib.update( { "porttag":'gps', "port" : 0 } )
            
        else: # else is PC's COM6 for me - port is off-by-one, so 0 = COM1, 5 = COM6
            ser.attrib.update( { "porttag":'com', "port" : 5, "baud": 4800 } )

        if ser.open():
            # then open worked
            return ser

        print "Attempting to open GPS device at %s failed" % ser.getName()
        print "Possible reasons:"
        print "1) This device may NOT have access to any GPS service;"
        print "   Confirm you have the correct hardware componants"
        print "2) Another Python script might be using the GPS equipment;"
        print "   Confirm no other scripts are running, then"
        print "   Reboot the product and try again."
        print
        print "This script will now sleep and rety in 60 seconds (forever)"

        del ser
        gc.collect() # make sure we don't build a surplus; since this is an
        # abnormal situation already, this call to gc should be okay
        time.sleep( 60.0)
        
    # this routine loops 'forever' until reboot or success

def run_main_loop( gps, for_secs = 0):
    """The main loop - run forever, unless error

    in: gps is the gps_system object
    in: for_secs, if NOT zero, then run that many seconds only
    """

    # this routine ONLY returns if we open serial port okay
    ser = open_serial_port()

    try:    
        start = time.time() # save the start-up time
        last_sentence = start # save time for idle line warnings

        # set secs to how long to run, or zero forever
        secs = 0
        if( for_secs == 0):
            print 'GPS tool: run forever'
        else:
            print 'GPS Tool: run for %d seconds, then stop' % for_secs
            
        while True:
            
            if( for_secs != 0):
                # this is test run only, so use raw time.time()
                if (time.time() > (start + for_secs)):
                    break
                
            data = ser.readline()
            gps.cache_time_now() # read once only
            if data:
                # print "rd<%s>" % data
                dct = nmea_to_dict( data)
                last_sentence = gps.get_time_now()
                gps.queue_sentence( dct)
            else: # else pause a bit - don't waste CPU cycles
                if( gps.get_time_now() > (last_sentence + GPS_NOMSG_WARNING)):
                    print "GPS Warning: no new GPS data in last %d seconds" % GPS_NOMSG_WARNING
                    last_sentence = gps.get_time_now()                
                time.sleep( 0.25)

    except:
        # always try to close it - else port is LOST & cannot be recovered without reboot
        traceback.print_exc()

    ser.close()

if __name__ == '__main__':

    test_all = False
    
    if( False or test_all):
        pass

    if( True):

        # alloc the objects
        gps = load_gps_system()

        # set for_secs to how long to run, or zero forever
        run_main_loop( gps, for_secs=0)


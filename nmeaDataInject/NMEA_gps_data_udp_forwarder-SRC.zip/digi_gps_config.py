#
# WARNING: only edit this file with a Python IDE or Windows WordPad
#
#          DO NOT USE WINDOWS NOTEPAD!!!
#

# No NEED to change these - constants used in dict
GPSDST_NAME = 'name' # user-friendly name
GPSDST_ISMOVE = 'ismoving' # True if moving
GPSDST_ISERR = 'iserror' # True if GPS is in error
GPSDST_LASTSEND = 'lastsendtime' # seconds since epoch of last send

GPSDST_ADDR = 'addr' # IP or DNS string destination (required)
GPSDST_TYPE = 'type' # default is 'udp' - only option for now
GPSDST_DPORT = 'dport' # Destination port (default: 2101)
GPSDST_SPORT = 'sport' # Source port (default: 0 for random/ephemeral)
GPSDST_MOOD = 'mood' # Mood (default: 'cost-aware', otherwise 'send-all' - actual use might be for future since we allow rates below)
GPSDST_ONLY = 'sendonly' # list of GPS Tags to send (default: 'RMC', None to send everything)
GPSDST_NOSEND = 'nosend' # GPS Tags *NOT* to send (default: None, else discard these. This setting ignored if Limit_To_GPS is not None)
GPSDST_PREFER = 'prefer' # GPS Tags Preferred (default: 'RMC' - the one to watch for idle/moving)
GPSDST_MOVING = 'moving' # Tolerance to define 'moving' - in knots
GPSDST_RATEIDLE = 'rate_idle' # Send rate when idle (default: once per 15*60 seconds, 0/off means send all)
GPSDST_RATEMOVE = 'rate_move' # Send rate when moving (default: once per 60 seconds, 0/off means send all)
GPSDST_RATEERR = 'rate_err' # Send rate when GPS error (default: same as idle)

# example GPS destination configs:
#
# Example 1: creates a destination named Amie, which sends only the basic RMC
#            summary to 192.168.196.6 via UDP port 2101. It uses the default times
#            which means an update once per 30 seconds while MOVING, and once
#            per 5 minutes when idle or the GPS has no signal
# { GPSDST_NAME:'amie', GPSDST_ADDR:'192.168.196.6', GPSDST_DPORT:2101,
# },
#
# Example 2: creates a destination named Bela, which sends only the basic RMC
#            summary to gojo.digi.com via UDP port 12222. It uses custom times
#            of once per 13 seconds while MOVING, and once per 15 minutes when
#           idle or the GPS has no signal
# { GPSDST_NAME:'bela', GPSDST_ADDR:'gojo.digi.com', GPSDST_DPORT:12222,
#   GPSDST_RATEIDLE:(15*60), GPSDST_RATEMOVE:13, GPSDST_RATEERR:(15*60),
# },
#
# Example 3: creates a destination named Cali, which sends ALL sentences
#            immediately to 192.168.196.6 via UDP port 1001. All times are forced
#            to zero (0), and the send-only id is cleared (was 'RMC' in ex 1 & 2)
# { GPSDST_NAME:'cali', GPSDST_ADDR:'192.168.196.6', GPSDST_DPORT:1001,
#   GPSDST_RATEIDLE:0, GPSDST_RATEMOVE:0, GPSDST_RATEERR:0,
#   GPSDST_ONLY:None,
# },
#

# here is the actual Python destination list - form is critical in this PILOT
# a future release might make it simplier, but for now edit carefully
GPS_DEST_LIST = [
    { GPSDST_NAME:'central', GPSDST_ADDR:'192.168.196.6', GPSDST_DPORT:2101,
      GPSDST_RATEIDLE:(15*60), GPSDST_RATEMOVE:30, GPSDST_RATEERR:(15*60),
    },

    { GPSDST_NAME:'local', GPSDST_ADDR:'192.168.196.6', GPSDST_DPORT:2102,
      GPSDST_RATEIDLE:0, GPSDST_RATEMOVE:0, GPSDST_RATEERR:0,
      GPSDST_ONLY:None,
    },
]

# the system-wide values; this is knots deemed moving vs not moving
GPS_SYSTEM_CONFIG = {
    GPSDST_MOVING : 4.0,
}

#
# Other System Default Values

# default 'publish' or transmit rate for Idle, Moving and error states
# time is in SECONDS, and you can enter 5 minutes as (5*60) or 300
GPSDST_RATEIDLE_DEF = (5*60)
GPSDST_RATEMOVE_DEF = 30
GPSDST_RATEERR_DEF = (5*60)

# These have NO default - enter something up above; don't put site-specific stuff here
# GPSDST_ADDR = 'addr' # IP or DNS string destination (required)
# GPSDST_TYPE = 'type' # default is 'udp' - only option for now
GPSDST_DPORT_DEF = 2101 # Destination port (default: 2101)
GPSDST_SPORT_DEF = 0    # Source port (default: 0 for random/ephemeral)

GPS_NOMSG_WARNING = 10

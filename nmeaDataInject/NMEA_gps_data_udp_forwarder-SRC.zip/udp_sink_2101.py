import socket
import time

# HOST = '192.168.196.6'
HOST = ''
PORT = 2101
BUFSIZ = 1024
ADDR = (HOST,PORT)

sock = socket.socket( socket.AF_INET, socket.SOCK_DGRAM)
sock.bind( ADDR)

print 'waiting for data on', ADDR
while True:
    data,addr = sock.recvfrom(BUFSIZ)
    print 'Recv from %s at %s' % (str(addr),time.ctime(time.time()))
    print data

sock.close()

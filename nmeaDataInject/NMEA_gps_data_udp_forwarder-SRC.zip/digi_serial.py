# Digi_Serial - create a serial object which works under Windows or NDS/CPX4

# standard includes
import os
import sys
import traceback
import types
import string
import errno

# prep for the local / non-standard ones
if( sys.platform.startswith('digi')):
    # then we are running on a Digi gateway
    digiSerial = True

else:
    # else is Windows - pyserial also works under Linux
    from serialwin32 import *
    digiSerial = False


# set to True to see Python traceback even in 'normal' exceptions
# leaving this on might confuse users who see Traceback info as bad news
# traceback() during pure unexpected errors is ALWAYS enabled
digi_serial_showTraceBack = True

# set to True to see any print output, else module is silent
digi_serial_showOutput = True
digi_serial_showError = True

# tags for the objects dictionary
SER_PORT = "port" # a zero-based number (COM1 = 0)
SER_BAUD = "baud"
SER_DBIT = "databit"
SER_SBIT = "stopbit"
SER_PAR = "parity" # upper case 'N' etc
SER_PORTAG = "porttag" # used to create OS name - like 'com' or 'gps'
SER_CTOUT = "char Tout" # ends semi-blocked read/recv

class serialPort:
    """Works for both PC and Digi Port"""

    def __init__( self):
        self.attrib = { SER_PORT : 0, SER_BAUD: 9600, SER_DBIT : 8,
                        SER_SBIT : 1, SER_PAR : 'N',
                        SER_PORTAG:'com', SER_CTOUT: 0.25 }
        self.fd = None
        self.buffer = "" # used by readline

    def __getitem__(self, tag):
        return( self.attrib[tag])

    def getName( self):
        if( digiSerial):
            st = '/%s/%d' % (self[SER_PORTAG],self[SER_PORT])
        else: # else PC
            st = '%s%d' % (self[SER_PORTAG],self[SER_PORT]+1)
            st = st.upper()
        return st

    def showSettings( self):
        return str(self)

    def __str__( self):
        st = "%s:%d,%d,%s,%d" % ( self.getName(), self[SER_BAUD], self[SER_DBIT], self[SER_PAR], self[SER_SBIT])
        return st

    def open( self):
        if digi_serial_showOutput:
            print "digi_serial().open(%s)" % self.showSettings()
        try:
            if( digiSerial):
                # set Digi for NONBLOCKING input
                self.fd = os.open( self.getName(), os.O_RDONLY | os.O_NONBLOCK)
            else:
                # on PC we use pyserial - Linux/Windows independent form
                par = string.upper( self.attrib.get( SER_PAR, "N") )
                self.fd = Serial( self[SER_PORT], self[SER_BAUD], self[SER_DBIT], par,
                               self[SER_SBIT], self[SER_CTOUT],
                               0)
            return True
        except:
            if digi_serial_showTraceBack: traceback.print_exc()
            if digi_serial_showError: print 'open failed'
            self.fd = None
        return False
    
    def recv( self, max=512):
        try:
            if( digiSerial):
                # we use select to have it block for shing (??)
                return os.read( self.fd, max)
            else:
                # pyserial is non-blocking
                return self.fd.read( max)

        except OSError, e:
            if( e.errno != errno.EAGAIN):
                # EAGAIN just means NO data ready
                if digi_serial_showTraceBack: traceback.print_exc()
                if digi_serial_showError: print 'error: serial port not open'
                self.fd = None
            
        return None

    def read( self, max=512):
        return self.recv(max)

    def readline( self, end='\n'):
        x = self.buffer.find(end)
        if( x < 0):
            # then not found; try reading more data
            data = self.recv()
            if not data:
                # then NOTHIN received
                return None
            
            # else something received, try find() again
            self.buffer += data
            x = self.buffer.find(end)

        if( x >= 0):
            line = self.buffer[:x+1]
            self.buffer = self.buffer[x+1:]
            return line

        return None

    def write( self, data):
        return self.send(data)
    
    def send( self, data):
        try:
            if( digiSerial):
                return os.write( self.fd, data)
            else:
                return self.fd.write( data)
        except:
            if digi_serial_showTraceBack: traceback.print_exc()
            if digi_serial_showError: print 'error: serial port not open'
            self.fd = None
        return None

    def close( self):
        if digi_serial_showOutput:
            print "digi_serial().close(%s)" % self.getName()
        try:
            if( digiSerial):
                return os.close( self.fd)
            else:
                return self.fd.close()
        except:
            if digi_serial_showTraceBack: traceback.print_exc()
        return None

if __name__ == '__main__':

    if( sys.platform.startswith('digi')):
        print ""
        print "Running on a Digi Gateway; reboot to stop/restart this program"
        print ""
        
    else:
        print ""
        print "Running on a PC; hit Ctrl-C to abort this program"
        print ""

    test_all = True

    # show_digi_map()

    ser = serialPort()
    ser.attrib.update( { SER_PORT:5, SER_BAUD:4800 } )
    ser.open()
    n = 10
    while( n > 0):
        data = ser.readline()
        if data:
            print "rd<%s>" % data
        else:
            print 'None'
        n = n -1
    ser.close()
    
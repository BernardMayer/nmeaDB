
import time

# config items

# set to true to calc the miles-per-hour and km-per-hour (is fast)
NMEA_DO_SPEED_EXTRA = True

# set to true to calc the UNIX/Python style time (is not so fast)
NMEA_DO_UNIX_TIME = True

NMEA_RAW = 'sentence' # includes $ etc

NMEA_TALKER = 'talker'
NMEA_SENID = 'senid'
NMEA_UTC = 'time'
NMEA_STAT = 'status'
NMEA_LAT = 'latitude'
NMEA_LATNS = 'lat_ns'
NMEA_LONG = 'longitude'
NMEA_LONGEW = 'long_ew'
NMEA_SPEED = 'speed_knots'
NMEA_DEGTRU = 'degtrue'
NMEA_DATE = 'date'

NMEA_MPH = 'speed_mph'
NMEA_KMH = 'speed_kmh'
NMEA_TIMTUP = 'tim_tup' # time() tuple
NMEA_TIMSEC = 'tim_sec' # time() secs since epoch

def nmea_strip_test( dct, raw=None):
    """Given NMEA sentence with warpper stuff, breakdown

    RMC = Recommended Minimum Navigation Information
    """

    if( raw):
        dct.update({ NMEA_RAW:raw })
    else:
        raw = dct.get( NMEA_RAW, "")

    # check the format
    if((len(raw) >= 7) and (raw[0] == '$')):
        # we need at least '$Pxxx[cr][nl]', plus the '$'

        # save the talker so we can remove later
        if( raw[1] == 'P'):
            # then proprietary
            dct.update({ NMEA_TALKER:'P' })
        else: # normal 2-letter
            dct.update({ NMEA_TALKER:raw[1:3] })

        # see if it has a checksum
        x = raw.rfind('*',4)
        if( x >= 0):
            # then has a checksum, test it
            cksum = 0
            for c in raw[1:x]:
                cksum ^= ord(c)
            if( ("%02X" % cksum) != raw[x+1:x+3]):
                dct.update({ NMEA_TALKER:None })
                print 'bad checksum'
                return dct, None
            
            raw = raw[3:x] # strip $, talker, *checksum, cr/nl
        else: # no checksum
            raw = raw.strip() # strip cr/nl - not sure if both there
            raw = raw[3:] # strip $ and talker

        # now we should have the RAW SENTENCE

    return dct, raw

def nmea_to_dict( gp):
    """Break an KNOWN sentence into a dictionary
    """

    # start with ALL bad defaults
    dct = { NMEA_TALKER:'??', NMEA_SENID:'???' }

    # strip extra around sentence, split it up into array of strings
    # 'talker' is also saved into dct
    dct, raw = nmea_strip_test( dct, gp)
    if raw:
        # then NMEA was something
        gptok = raw.split(',')
        
        try:
            dct.update({NMEA_SENID:gptok[0]})
            
        except:
            # some error!
            print 'error: nmea_rmc_to_dict() - not enough tokens on <%s>' % gp
            return dct

        if( dct[NMEA_SENID] == "RMC"):
            return nmea_rmc_to_dict( dct, gptok)
    
    return dct

def nmea_rmc_to_dict( dct, gptok):
    """Break an RMC sentence into a dictionary

    RMC = Recommended Minimum Navigation Information
    """

    if( gptok[0] != "RMC"):
        print 'error: nmea_rmc_to_dict() - sentence is NOT RMC', dct
        return dct

    # start with ALL bad defaults
    dct.update( { NMEA_SENID:'RMC', NMEA_STAT:'V',
            NMEA_DEGTRU:0.0, NMEA_LAT:0.0, NMEA_LATNS:'?', NMEA_LONG:0.0, NMEA_LONGEW:'?',
            NMEA_UTC:None, NMEA_DATE:None, NMEA_TIMTUP:None, NMEA_TIMSEC:None,
            NMEA_SPEED:0.0, NMEA_MPH:0.0, NMEA_KMH:0.0 } )

    # gp  = "$GPRMC,154516.000,A,4453.8294,N,09324.9550,W,0.35,189.45,070209,,*1C"
    # raw = "RMC,154516.000,A,4453.8294,N,09324.9550,W,0.35,189.45,070209,,"
    # [0] = 'RMC',          tag/header ('$' & talker removed)
    # [1] = '154516.000',   UTC as HHMMSS.ss
    # [2] = 'A',            Status (A=valid, V=warning?)
    # [3] = '4453.8294'     Latitude
    # [4] = 'N',            N or S
    # [5] = '09324.9550',   Longitude
    # [6] = 'W',            E or W
    # [7] = '0.35',         Speed over ground, in knots
    # [8] = '189.45',       Track made good, degrees true
    # [9] = '070209',       Date as DDMMYY
    # [10] = '',            Magnetic Variation
    # [11] = ''             E or W (nul) ('*1C' checksum removed)

    try:
        dct.update({ NMEA_SENID:gptok[0], NMEA_STAT:gptok[2] })
        
    except:
        # some error!
        print 'error: nmea_rmc_to_dict() - not enough tokens on <%s>' % dct[NMEA_RAW]
        return dct

    if( dct[NMEA_STAT] != 'A'):
        print 'warn: nmea_rmc_to_dict() - RMC status is bad/warning <%s>' % dct[NMEA_RAW]
        return dct
    # else we have a sentence we can handle

    if( len(gptok) != 12):
        # some error!
        print 'error: nmea_rmc_to_dict() - not enough tokens on <%s>' % dct[NMEA_RAW]
        return dct
    
    # do latitude/longitude
    try:
        dct.update( { NMEA_LAT:float(gptok[3]), NMEA_LATNS:gptok[4],
                      NMEA_LONG:float(gptok[5]), NMEA_LONGEW:gptok[6] })
    except:
        pass # leave as 0.0 etc

    # do time/date conversion
    dct.update( { NMEA_UTC:gptok[1], NMEA_DATE:gptok[9] } )
    if( NMEA_DO_UNIX_TIME):
        # set to true to calc the UNIX/Python style time (is not so fast)
        try:
            tim = gptok[9] + gptok[1] # is DDMMYYHHMMSS.000
            tim = time.strptime( tim, "%d%m%y%H%M%S.000")
            dct.update( { NMEA_TIMTUP : tim } ) # time tuple
            dct.update( { NMEA_TIMSEC : time.mktime( tim) } ) # sec since epoch
        except:
            pass # leave as 0.0 etc

    # do speed conversion
    try:
        speed = float( gptok[7])
        dct.update( { NMEA_SPEED:speed } ) # is in KNOTS
        if( NMEA_DO_SPEED_EXTRA):
            # set to true to calc the miles-per-hour and km-per-hour (is fast)
            dct.update( { NMEA_MPH:(speed*1.15077945),  # miles-per-hour
                          NMEA_KMH:(speed*1.1852)}) # km-per-hour
    except:
        pass # leave as 0.0 etc
        
    # do tracking
    try:
        dct.update( { NMEA_DEGTRU:float(gptok[8])})
    except:
        pass # leave as 0.0 etc

    return dct

def test_nmea_rmc_to_dict( ):

    print 'test nmea_rmc_to_dict() ...',

    gps = "$GPRMC,154516.000,A,4453.8294,N,09324.9550,W,0.35,189.45,070209,,*1C"

    # [0] = '$GPRMC',       tag/header
    # [1] = '154516.000',   UTC as HHMMSS.ss
    # [2] = 'A',            Status (V=warning?)
    # [3] = '4453.8294'     Latitude
    # [4] = 'N',            N or S
    # [5] = '09324.9550',   Longitude
    # [6] = 'W',            E or W
    # [7] = '0.35',         Speed over ground, in knots
    # [8] = '189.45',       Track made good, degrees true
    # [9] = '070209',       Date as DDMMYY
    # [10] = '',            Magnetic Variation
    # [11] = '*1C'          E or W (nul), '*' is end, '1C' is checksum

    dct = nmea_rmc_to_dict( gps)
    print dct

    return True

if __name__ == '__main__':

    import digi_serial

    test_all = False
    
    if( False or test_all):
        test_nmea_rmc_to_dict()

    if( True):
        ser = digi_serial.serialPort()
        ser.attrib.update( { "port" : 5, "baud": 4800 } )
        ser.open()
        n = 100
        while( n > 0):
            data = ser.readline()
            if data:
                print "rd<%s>" % data
                dct = nmea_to_dict( data)
                if( dct.get( NMEA_SENID, None) == "RMC"):
                    print dct
                    try:
                        print 'time = ', time.ctime( dct[NMEA_TIMSEC] )
                    except:
                        print 'time format is bad'
                print '---'
            else:
                print 'None'
            n = n -1
        ser.close()
    
